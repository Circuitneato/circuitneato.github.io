#ifdef VIRTIOCON

#include "virtio_config.h"
#include "open-amp/lib/virtio/virtio.c"

#endif /* VIRTIOCON */
