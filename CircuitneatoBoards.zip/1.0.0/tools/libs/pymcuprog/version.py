""" This file was generated when pymcuprog was built """
VERSION = '3.6.4.86'
COMMIT_ID = '6224623cfc85c5e7cb6b1df8419b72c338c223f9'
BUILD_DATE = '2020-11-09 14:49:15 +0000'
